import * as vscode from "vscode";
import * as path from "path";

export async function runDAD() {
  const workspace = vscode.workspace.workspaceFolders?.[0];
  if (!workspace) {
    vscode.window.showErrorMessage("Please open a project folder.");
    return;
  }

  const url = await vscode.window.showInputBox({
    prompt: "Enter URL to test",
    value: "http://localhost:3000"
  });

  if (!url) return;

  const headful = await vscode.window.showQuickPick(
    ["Yes", "No"],
    { placeHolder: "Show browser window?" }
  );

  const runtimePath = path.join(
    workspace.uri.fsPath,
    "dad-cli-main",
    "runtime-discovery"
  );

  const terminal = vscode.window.createTerminal("DAD Test");
  terminal.show();
  
  const headfulFlag = headful === "Yes" ? " --headful" : "";
  
  // Use PowerShell-compatible syntax
  if (process.platform === "win32") {
    terminal.sendText(`cd "${runtimePath}"; npm run start -- ${url}${headfulFlag}`);
  } else {
    terminal.sendText(`cd "${runtimePath}" && npm run start -- ${url}${headfulFlag}`);
  }
}
